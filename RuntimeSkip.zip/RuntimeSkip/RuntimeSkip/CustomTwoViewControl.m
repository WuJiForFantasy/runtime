//
//  CustomTwoViewControl.m
//  RuntimeSkip
//
//  Created by tqh on 15/9/8.
//  Copyright (c) 2015年 tqh. All rights reserved.
//

#import "CustomTwoViewControl.h"

@interface CustomTwoViewControl ()

@end

@implementation CustomTwoViewControl

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    NSLog(@"customTwo,ID=%@",_ID);
    NSLog(@"model的属性 name=%@,age=%ld",_model.name,_model.age);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
