//
//  CustomTwoViewControl.h
//  RuntimeSkip
//
//  Created by tqh on 15/9/8.
//  Copyright (c) 2015年 tqh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomModel.h"
@interface CustomTwoViewControl : UIViewController

// 注：根据下面的两个属性，可以从服务器获取对应的频道列表数据

/** 频道ID */
@property (nonatomic, copy) NSString *ID;

/** 频道type */
@property (nonatomic, copy) NSString *type;

@property (nonatomic,strong)CustomModel *model;

@end
