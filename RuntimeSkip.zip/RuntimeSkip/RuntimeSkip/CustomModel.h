//
//  CustomModel.h
//  RuntimeSkip
//
//  Created by tqh on 15/9/8.
//  Copyright (c) 2015年 tqh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CustomModel : NSObject

@property (nonatomic,copy)NSString *name;
@property (nonatomic,assign)NSInteger age;

@end
