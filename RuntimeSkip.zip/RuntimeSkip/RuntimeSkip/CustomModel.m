//
//  CustomModel.m
//  RuntimeSkip
//
//  Created by tqh on 15/9/8.
//  Copyright (c) 2015年 tqh. All rights reserved.
//

#import "CustomModel.h"

@implementation CustomModel

@end
