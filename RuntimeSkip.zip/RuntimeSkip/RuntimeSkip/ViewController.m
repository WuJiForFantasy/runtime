//
//  ViewController.m
//  RuntimeSkip
//
//  Created by tqh on 15/9/8.
//  Copyright (c) 2015年 tqh. All rights reserved.
//

#import "ViewController.h"
//#import <objc/runtime.h>
#import "CustomModel.h"
#import "WJRuntime.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    static NSInteger index = 0;
    index ++;
    NSArray *array = [[NSArray alloc]initWithObjects:@"CustomViewController",@"CustomTwoViewControl", nil];
    //2.0秒后进行
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        CustomModel *model = [[CustomModel alloc]init];
        model.name = @"name";
        model.age = 10;
        [WJRuntime runtimePush:array[index%2] dic:@{@"id":@"12",@"ID":@"21",@"model":model} nav:self.navigationController];
    });
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

//
////runtime跳转
//
//- (void)runtimePush:(NSString *)vcName dic:(NSDictionary *)dic nav:(UINavigationController *)nav{
//    //类名(对象名)
//    
//    NSString *class = vcName;
//    
//    const char *className = [class cStringUsingEncoding:NSASCIIStringEncoding];
//    Class newClass = objc_getClass(className);
//    if (!newClass) {
//        //创建一个类
//        Class superClass = [NSObject class];
//        newClass = objc_allocateClassPair(superClass, className, 0);
//        //注册你创建的这个类
//        objc_registerClassPair(newClass);
//    }
//    // 创建对象(写到这里已经可以进行随机页面跳转了)
//    id instance = [[newClass alloc] init];
//    
//    //下面是传值－－－－－－－－－－－－－－
//    
//    [dic enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
//        if ([self checkIsExistPropertyWithInstance:instance verifyPropertyName:key]) {
//            //kvc给属性赋值
//            
//            [instance setValue:obj forKey:key];
//        }else {
//            NSLog(@"不包含key=%@的属性",key);
//        }
//    }];
//    [nav pushViewController:instance animated:YES];
//    
//}
///**
// *  检测对象是否存在该属性
// */
//- (BOOL)checkIsExistPropertyWithInstance:(id)instance verifyPropertyName:(NSString *)verifyPropertyName
//{
//    unsigned int outCount, i;
//    
//    // 获取对象里的属性列表
//    objc_property_t * properties = class_copyPropertyList([instance
//                                                           class], &outCount);
//    
//    for (i = 0; i < outCount; i++) {
//        objc_property_t property =properties[i];
//        //  属性名转成字符串
//        NSString *propertyName = [[NSString alloc] initWithCString:property_getName(property) encoding:NSUTF8StringEncoding];
//        // 判断该属性是否存在
//        if ([propertyName isEqualToString:verifyPropertyName]) {
//            free(properties);
//            return YES;
//        }
//    }
//    free(properties);
//    
//    return NO;
//}

@end
