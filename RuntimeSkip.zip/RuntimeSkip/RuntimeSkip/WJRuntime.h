//
//  WJRuntime.h
//  RuntimeSkip
//
//  Created by tqh on 15/9/8.
//  Copyright (c) 2015年 tqh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface WJRuntime : NSObject
/**
 *
 *  @param vcName 需要推送到的控制器的名称
 *  @param dic    字典里面key＝属性（可以是模型）,value＝值
 *  @param nav    导航控制器
 */
+ (void)runtimePush:(NSString *)vcName dic:(NSDictionary *)dic nav:(UINavigationController *)nav;

@end
